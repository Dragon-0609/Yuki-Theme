The Doki Theme Master
---

Hey friend! It looks like you eventually found your way over here, welcome!

So as you may have noticed, I have a bit of a collection going.
Instead of being one of those guys that has a awesome rooms filled with anime figurines and decor.
I'm just a hacker weeb with a ton of anime themed tools....

So if you want to make suggestions of additions to my collections. 
Feel free to [submit a theme request](https://github.com/doki-theme/doki-master-theme/issues).
A lot of love, care, and time goes into each theme.
So you may or may not get a theme. 
However, that doesn't mean that you shouldn't at least ask.
The worst thing that could happen is that I say no.
You miss all the shots you don't take. 
Who knows, you might help somebody else find best girl!

Anyways, this is the central place for all things Doki Theme related. 
If you want to suggest a new platform, asset, theme, or anything else that affects all the platforms.
This is the place for that. Please keep issues to a specific platform in that plugin's repository.



## I hope you enjoy these themes!


![Best Girls](./readmeAssets/best_girls.png)


---
<div align="center">
    <img src="https://doki.assets.unthrottled.io/misc/logo.svg" ></img>
</div>


